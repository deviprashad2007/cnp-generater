import { supabase } from '../config/supabase';
import { CNPRecord, AdminSettings, AdminUser } from '../types/admin';

export async function getUsers(): Promise<AdminUser[]> {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function updateUserRole(userId: string, role: string) {
  const { error } = await supabase
    .from('users')
    .update({ role })
    .eq('id', userId);

  if (error) throw error;
}

export async function saveCNPRecord(record: Omit<CNPRecord, 'id' | 'created_at'>) {
  const { data, error } = await supabase
    .from('cnp_records')
    .insert(record)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function getCNPRecords() {
  const { data, error } = await supabase
    .from('cnp_records')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function getAdminSettings() {
  const { data, error } = await supabase
    .from('admin_settings')
    .select('*');

  if (error) throw error;
  return data;
}

export async function updateAdminSettings(
  key: string,
  value: any
) {
  const { data, error } = await supabase
    .from('admin_settings')
    .upsert({
      setting_key: key,
      setting_value: value,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}