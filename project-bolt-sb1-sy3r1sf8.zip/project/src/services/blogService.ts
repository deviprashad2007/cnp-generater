import { supabase } from '../config/supabase';
import type { BlogPost } from '../types/blog';

export async function getBlogPosts(): Promise<BlogPost[]> {
  const { data, error } = await supabase
    .from('blog_posts')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Error fetching blog posts: ${error.message}`);
  }

  return data || [];
}