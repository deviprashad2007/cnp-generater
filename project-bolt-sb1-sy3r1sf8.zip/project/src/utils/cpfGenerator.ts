// CPF Generator utility functions
export function generateRandomDigit(): number {
  return Math.floor(Math.random() * 10);
}

export function calculateCheckDigit(digits: number[]): number {
  const sum = digits.reduce((acc, digit, index) => {
    return acc + digit * (digits.length + 1 - index);
  }, 0);
  const remainder = sum % 11;
  return remainder < 2 ? 0 : 11 - remainder;
}

export function generateCPF(withMask = true): string {
  // Generate first 9 digits
  const digits: number[] = Array.from({ length: 9 }, generateRandomDigit);
  
  // Calculate first check digit
  const firstCheckDigit = calculateCheckDigit(digits);
  digits.push(firstCheckDigit);
  
  // Calculate second check digit
  const secondCheckDigit = calculateCheckDigit(digits);
  digits.push(secondCheckDigit);
  
  const cpf = digits.join('');
  
  return withMask 
    ? `${cpf.slice(0, 3)}.${cpf.slice(3, 6)}.${cpf.slice(6, 9)}-${cpf.slice(9)}`
    : cpf;
}