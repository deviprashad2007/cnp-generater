import { Gender } from '../types/cnp';
import { COUNTY_CODES } from '../data/counties';
import { calculateControlDigit } from './cnpValidator';

export function generateCNP(birthDate: Date, gender: 'M' | 'F', county: string): string {
  // Determine gender code
  const year = birthDate.getFullYear();
  let genderCode: Gender;
  
  if (year >= 1800 && year <= 1899) {
    genderCode = gender === 'M' ? 3 : 4;
  } else if (year >= 1900 && year <= 1999) {
    genderCode = gender === 'M' ? 1 : 2;
  } else {
    genderCode = gender === 'M' ? 5 : 6;
  }

  // Format date components
  const yearStr = year.toString().slice(-2);
  const monthStr = (birthDate.getMonth() + 1).toString().padStart(2, '0');
  const dayStr = birthDate.getDate().toString().padStart(2, '0');

  // Generate random sequence
  const sequence = Math.floor(Math.random() * 999).toString().padStart(3, '0');

  // Combine CNP without control digit
  const cnpWithoutControl = `${genderCode}${yearStr}${monthStr}${dayStr}${county}${sequence}`;

  // Calculate and append control digit
  const controlDigit = calculateControlDigit(cnpWithoutControl);

  return cnpWithoutControl + controlDigit;
}