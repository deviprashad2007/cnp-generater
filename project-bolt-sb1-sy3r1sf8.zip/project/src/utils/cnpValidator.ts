import { CNPComponents, Gender } from '../types/cnp';
import { COUNTY_CODES } from '../data/counties';

const CONTROL_WEIGHTS = [2, 7, 9, 1, 4, 6, 3, 5, 8, 2, 7, 9];

export function calculateControlDigit(cnp: string): number {
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    sum += parseInt(cnp[i]) * CONTROL_WEIGHTS[i];
  }
  const remainder = sum % 11;
  return remainder === 10 ? 1 : remainder;
}

export function validateCNP(cnp: string): boolean {
  if (!/^\d{13}$/.test(cnp)) {
    return false;
  }

  const components = parseCNP(cnp);
  if (!components) {
    return false;
  }

  const controlDigit = calculateControlDigit(cnp);
  return controlDigit === parseInt(cnp[12]);
}

export function parseCNP(cnp: string): CNPComponents | null {
  if (!/^\d{13}$/.test(cnp)) {
    return null;
  }

  const gender = parseInt(cnp[0]) as Gender;
  const year = parseInt(cnp.slice(1, 3));
  const month = parseInt(cnp.slice(3, 5));
  const day = parseInt(cnp.slice(5, 7));
  const county = cnp.slice(7, 9);
  const sequence = parseInt(cnp.slice(9, 12));
  const control = parseInt(cnp[12]);

  // Validate gender
  if (![1, 2, 3, 4, 5, 6, 7, 8].includes(gender)) {
    return null;
  }

  // Validate county
  if (!(county in COUNTY_CODES)) {
    return null;
  }

  // Validate date
  const fullYear = getFullYear(year, gender);
  const date = new Date(fullYear, month - 1, day);
  if (
    date.getFullYear() !== fullYear ||
    date.getMonth() !== month - 1 ||
    date.getDate() !== day
  ) {
    return null;
  }

  return { gender, year, month, day, county, sequence, control };
}

function getFullYear(year: number, gender: Gender): number {
  switch (gender) {
    case 1:
    case 2:
      return 1900 + year;
    case 3:
    case 4:
      return 1800 + year;
    case 5:
    case 6:
      return 2000 + year;
    default: // 7, 8 for residents
      return 1900 + year;
  }
}