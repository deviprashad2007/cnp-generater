interface CNPFormData {
  birthDate: string;
  gender: string;
  county: string;
}

export function calculateCheckDigit(cnp: string): number {
  const weights = [2, 7, 9, 1, 4, 6, 3, 5, 8, 2, 7, 9];
  let sum = 0;
  for (let i = 0; i < cnp.length; i++) {
    sum += parseInt(cnp[i]) * weights[i];
  }
  const remainder = sum % 11;
  return remainder === 10 ? 1 : remainder;
}

export function generateCNP({ birthDate, gender, county }: CNPFormData): string {
  const date = new Date(birthDate);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const yearShort = String(year).slice(-2);

  let centuryAdjustedGender = gender;
  if (year >= 2000) {
    centuryAdjustedGender = String(parseInt(gender) + 4);
  }

  const sequentialNumber = String(Math.floor(Math.random() * 900) + 100);
  const partialCNP = `${centuryAdjustedGender}${yearShort}${month}${day}${county}${sequentialNumber}`;
  const controlDigit = calculateCheckDigit(partialCNP);
  
  return `${partialCNP}${controlDigit}`;
}