import { useState } from 'react';
import { updateAdminSettings } from '../../services/adminService';
import { AdminSettings } from '../../types/admin';
import { Button } from '../common/Button';

interface SettingsPanelProps {
  settings: AdminSettings[];
  onUpdate: () => void;
}

export function SettingsPanel({ settings, onUpdate }: SettingsPanelProps) {
  const [editing, setEditing] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  async function handleSave(settingKey: string) {
    try {
      await updateAdminSettings(settingKey, JSON.parse(editValue));
      setEditing(null);
      onUpdate();
    } catch (err) {
      alert('Failed to update setting');
    }
  }

  return (
    <div className="space-y-4">
      {settings.map((setting) => (
        <div key={setting.id} className="flex justify-between items-center p-2 hover:bg-gray-50">
          <span className="font-medium">{setting.setting_key}</span>
          {editing === setting.setting_key ? (
            <div className="flex gap-2">
              <input
                type="text"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="border rounded px-2 py-1"
              />
              <Button onClick={() => handleSave(setting.setting_key)}>Save</Button>
              <Button onClick={() => setEditing(null)}>Cancel</Button>
            </div>
          ) : (
            <div className="flex gap-2 items-center">
              <span>{JSON.stringify(setting.setting_value)}</span>
              <Button
                onClick={() => {
                  setEditValue(JSON.stringify(setting.setting_value));
                  setEditing(setting.setting_key);
                }}
              >
                Edit
              </Button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}