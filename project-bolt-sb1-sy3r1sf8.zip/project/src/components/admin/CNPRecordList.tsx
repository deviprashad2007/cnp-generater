import { CNPRecord } from '../../types/admin';
import { COUNTY_CODES } from '../../data/counties';

interface CNPRecordListProps {
  records: CNPRecord[];
}

export function CNPRecordList({ records }: CNPRecordListProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b">
            <th className="text-left py-2">CNP</th>
            <th className="text-left py-2">Gender</th>
            <th className="text-left py-2">Birth Date</th>
            <th className="text-left py-2">County</th>
            <th className="text-left py-2">Created</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record) => (
            <tr key={record.id} className="border-b">
              <td className="py-2">{record.cnp}</td>
              <td className="py-2">{record.gender === '1' ? 'Male' : 'Female'}</td>
              <td className="py-2">{new Date(record.birth_date).toLocaleDateString()}</td>
              <td className="py-2">{COUNTY_CODES[record.county_code]}</td>
              <td className="py-2">{new Date(record.created_at).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}