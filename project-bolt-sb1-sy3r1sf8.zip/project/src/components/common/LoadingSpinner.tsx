export function LoadingSpinner() {
  return (
    <div className="animate-pulse space-y-4">
      {[1, 2, 3].map((n) => (
        <div key={n} className="h-40 bg-gray-200 rounded-lg" />
      ))}
    </div>
  );
}