interface FormFieldProps {
  id: string;
  label: string;
  required?: boolean;
  children: React.ReactNode;
}

export function FormField({ id, label, required, children }: FormFieldProps) {
  return (
    <div>
      <label htmlFor={id} className="block font-medium mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
    </div>
  );
}