interface CNPResultProps {
  cnp: string;
}

export function CNPResult({ cnp }: CNPResultProps) {
  return (
    <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
      <p className="text-center text-green-800 font-semibold">
        Generated CNP: {cnp}
      </p>
    </div>
  );
}