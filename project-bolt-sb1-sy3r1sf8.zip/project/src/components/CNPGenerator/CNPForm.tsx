import { useState } from 'react';
import { COUNTY_CODES } from '../../data/counties';
import { FormField } from '../common/FormField';
import { Button } from '../common/Button';

interface CNPFormProps {
  onSubmit: (data: { birthDate: string; gender: string; county: string }) => void;
}

export function CNPForm({ onSubmit }: CNPFormProps) {
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState('1');
  const [county, setCounty] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!birthDate || !county) {
      alert('Please fill in all required fields');
      return;
    }
    onSubmit({ birthDate, gender, county });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <FormField
        id="gender"
        label="Gender"
        required
      >
        <select
          id="gender"
          value={gender}
          onChange={(e) => setGender(e.target.value)}
          className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
        >
          <option value="1">Male</option>
          <option value="2">Female</option>
        </select>
      </FormField>

      <FormField
        id="birthdate"
        label="Birth Date"
        required
      >
        <input
          type="date"
          id="birthdate"
          value={birthDate}
          onChange={(e) => setBirthDate(e.target.value)}
          className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
          required
        />
      </FormField>

      <FormField
        id="county"
        label="County"
        required
      >
        <select
          id="county"
          value={county}
          onChange={(e) => setCounty(e.target.value)}
          className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
          required
        >
          <option value="">Select county</option>
          {Object.entries(COUNTY_CODES).map(([code, name]) => (
            <option key={code} value={code}>
              {name}
            </option>
          ))}
        </select>
      </FormField>

      <Button type="submit">Generate CNP</Button>
    </form>
  );
}