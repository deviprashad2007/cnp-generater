import { useState } from 'react';
import { CNPForm } from './CNPForm';
import { CNPResult } from './CNPResult';
import { generateCNP } from '../../utils/cnpUtils';
import { saveCNPRecord } from '../../services/adminService';
import { useAuth } from '../../hooks/useAuth';

export function CNPGenerator() {
  const [generatedCNP, setGeneratedCNP] = useState('');
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const handleGenerate = async (formData: { birthDate: string; gender: string; county: string }) => {
    try {
      const cnp = generateCNP(formData);
      setGeneratedCNP(cnp);

      // Save record if user is authenticated
      if (user) {
        await saveCNPRecord({
          cnp,
          gender: formData.gender,
          birth_date: formData.birthDate,
          county_code: formData.county,
          created_by: user.id
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate CNP');
    }
  };

  return (
    <div className="max-w-md mx-auto p-8 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-center mb-6">Generate CNP</h2>
      {error && (
        <div className="mb-4 p-4 bg-red-50 text-red-700 rounded-lg">
          {error}
        </div>
      )}
      <CNPForm onSubmit={handleGenerate} />
      {generatedCNP && <CNPResult cnp={generatedCNP} />}
    </div>
  );
}