import { useState } from 'react';
import { validateCNP, parseCNP } from '../utils/cnpValidator';
import { COUNTY_CODES } from '../data/counties';

export function CNPValidator() {
  const [cnp, setCnp] = useState('');
  const [result, setResult] = useState<{ valid: boolean; details?: string }>({ valid: false });

  const handleValidate = () => {
    const isValid = validateCNP(cnp);
    if (isValid) {
      const components = parseCNP(cnp);
      if (components) {
        const county = COUNTY_CODES[components.county as keyof typeof COUNTY_CODES];
        setResult({
          valid: true,
          details: `Valid CNP from ${county} county`
        });
      }
    } else {
      setResult({ valid: false });
    }
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <div className="space-y-4">
        <div>
          <label htmlFor="cnp" className="block font-bold mb-1">CNP:</label>
          <input
            type="text"
            id="cnp"
            value={cnp}
            onChange={(e) => setCnp(e.target.value)}
            className="w-full p-2 border rounded"
            maxLength={13}
            placeholder="Enter CNP to validate"
          />
        </div>

        <button
          onClick={handleValidate}
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition-colors"
        >
          Validate CNP
        </button>

        {result.details && (
          <div className={`mt-4 p-4 rounded text-center ${
            result.valid ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
          }`}>
            {result.details}
          </div>
        )}
      </div>
    </div>
  );
}