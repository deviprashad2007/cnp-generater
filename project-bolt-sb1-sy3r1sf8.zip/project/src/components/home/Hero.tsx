import { Link } from 'react-router-dom';

export function Hero() {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">
          Romanian CNP Generator & Validator
        </h1>
        <p className="text-xl mb-8 text-blue-100">
          Generate valid Romanian Personal Numerical Codes (CNP) instantly and verify existing ones with our free online tools.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/validator"
            className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
          >
            Validate CNP
          </Link>
        </div>
      </div>
    </div>
  );
}