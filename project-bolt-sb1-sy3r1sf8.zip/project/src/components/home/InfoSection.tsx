export function InfoSection() {
  return (
    <div className="py-16">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">About Romanian CNP</h2>
        <div className="prose lg:prose-lg">
          <p>
            The Personal Numerical Code (CNP) is a unique identifier assigned to each Romanian citizen and resident.
            It consists of 13 digits that encode important personal information:
          </p>
          <ul>
            <li>Gender and century of birth (1st digit)</li>
            <li>Year of birth (digits 2-3)</li>
            <li>Month of birth (digits 4-5)</li>
            <li>Day of birth (digits 6-7)</li>
            <li>County code (digits 8-9)</li>
            <li>Unique sequence number (digits 10-12)</li>
            <li>Control digit (13th digit)</li>
          </ul>
          <h3>Usage and Importance</h3>
          <p>
            The CNP is used in various official contexts in Romania, including:
          </p>
          <ul>
            <li>Identity verification</li>
            <li>Healthcare services</li>
            <li>Tax administration</li>
            <li>Social security</li>
            <li>Banking services</li>
          </ul>
        </div>
      </div>
    </div>
  );
}