import { BlogPost } from '../../types/blog';
import { BlogCard } from './BlogCard';

interface BlogListProps {
  posts: BlogPost[];
}

export function BlogList({ posts }: BlogListProps) {
  if (posts.length === 0) {
    return (
      <p className="text-gray-500 text-center py-8">
        No blog posts available yet.
      </p>
    );
  }

  return (
    <div className="space-y-6">
      {posts.map((post) => (
        <BlogCard key={post.id} post={post} />
      ))}
    </div>
  );
}