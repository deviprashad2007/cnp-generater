import { BlogCardProps } from '../../types/blog';
import { formatDate } from '../../utils/dateUtils';

export function BlogCard({ post }: BlogCardProps) {
  return (
    <article className="bg-white rounded-lg shadow-md overflow-hidden">
      {post.image_url && (
        <img 
          src={post.image_url} 
          alt={post.title}
          className="w-full h-48 object-cover"
        />
      )}
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-2">{post.title}</h2>
        <p className="text-gray-600 mb-4">
          {formatDate(post.created_at)}
        </p>
        <p className="text-gray-700 mb-4">{post.excerpt}</p>
        <div className="flex items-center text-sm text-gray-500">
          <img 
            src={post.author_avatar || '/default-avatar.png'} 
            alt={post.author_name}
            className="w-8 h-8 rounded-full mr-2"
          />
          <span>{post.author_name}</span>
        </div>
      </div>
    </article>
  );
}