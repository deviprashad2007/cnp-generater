import { FormEvent, useState } from 'react';
import { ROMANIAN_COUNTIES } from '../data/counties';
import { generateCNP } from '../utils/cnpGenerator';
import { Gender } from '../types';

export function CNPForm() {
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<Gender | ''>('');
  const [countyCode, setCountyCode] = useState('');
  const [result, setResult] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!birthDate || !gender || !countyCode) {
      setError('Please fill in all fields.');
      return;
    }

    const cnp = generateCNP(gender as Gender, birthDate, countyCode);
    setResult(cnp);
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="birthDate" className="block font-bold mb-1">Birth Date:</label>
          <input
            type="date"
            id="birthDate"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className="w-full p-2 border rounded"
            required
          />
        </div>

        <div>
          <label htmlFor="gender" className="block font-bold mb-1">Gender:</label>
          <select
            id="gender"
            value={gender}
            onChange={(e) => setGender(e.target.value as Gender)}
            className="w-full p-2 border rounded"
            required
          >
            <option value="">Select gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>

        <div>
          <label htmlFor="county" className="block font-bold mb-1">County:</label>
          <select
            id="county"
            value={countyCode}
            onChange={(e) => setCountyCode(e.target.value)}
            className="w-full p-2 border rounded"
            required
          >
            <option value="">Select county</option>
            {ROMANIAN_COUNTIES.map(county => (
              <option key={county.code} value={county.code}>
                {county.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition-colors"
        >
          Generate CNP
        </button>
      </form>

      {error && (
        <div className="mt-4 p-4 bg-red-100 text-red-700 rounded">
          {error}
        </div>
      )}
      
      {result && (
        <div className="mt-4 p-4 bg-blue-100 text-blue-700 rounded text-center font-bold">
          Generated CNP: {result}
        </div>
      )}
    </div>
  );
}