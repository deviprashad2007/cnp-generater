import { useState } from 'react';
import { COUNTY_CODES } from '../data/counties';

export function CNPGenerator() {
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState('1');
  const [county, setCounty] = useState('');
  const [generatedCNP, setGeneratedCNP] = useState('');

  const calculateCheckDigit = (cnp: string): number => {
    const weights = [2, 7, 9, 1, 4, 6, 3, 5, 8, 2, 7, 9];
    let sum = 0;
    for (let i = 0; i < cnp.length; i++) {
      sum += parseInt(cnp[i]) * weights[i];
    }
    const remainder = sum % 11;
    return remainder === 10 ? 1 : remainder;
  };

  const handleGenerate = () => {
    if (!birthDate || !county) {
      alert('Please fill in all required fields');
      return;
    }

    const date = new Date(birthDate);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const yearShort = String(year).slice(-2);

    let centuryAdjustedGender = gender;
    if (year >= 2000) {
      centuryAdjustedGender = String(parseInt(gender) + 4);
    }

    const sequentialNumber = String(Math.floor(Math.random() * 900) + 100);
    const partialCNP = `${centuryAdjustedGender}${yearShort}${month}${day}${county}${sequentialNumber}`;
    const controlDigit = calculateCheckDigit(partialCNP);
    const cnp = `${partialCNP}${controlDigit}`;

    setGeneratedCNP(cnp);
  };

  return (
    <div className="max-w-md mx-auto p-8 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-center mb-6">Generate CNP</h2>
      
      <div className="space-y-4">
        <div>
          <label htmlFor="gender" className="block font-medium mb-1">
            Gender: <span className="text-red-500">*</span>
          </label>
          <select
            id="gender"
            value={gender}
            onChange={(e) => setGender(e.target.value)}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
          >
            <option value="1">Male</option>
            <option value="2">Female</option>
          </select>
        </div>

        <div>
          <label htmlFor="birthdate" className="block font-medium mb-1">
            Birth Date: <span className="text-red-500">*</span>
          </label>
          <input
            type="date"
            id="birthdate"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label htmlFor="county" className="block font-medium mb-1">
            County: <span className="text-red-500">*</span>
          </label>
          <select
            id="county"
            value={county}
            onChange={(e) => setCounty(e.target.value)}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            required
          >
            <option value="">Select county</option>
            {Object.entries(COUNTY_CODES).map(([code, name]) => (
              <option key={code} value={code}>
                {name}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleGenerate}
          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2 px-4 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 shadow-md hover:shadow-lg"
        >
          Generate CNP
        </button>

        {generatedCNP && (
          <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-center text-green-800 font-semibold">
              Generated CNP: {generatedCNP}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}