import { CopyButton } from './CopyButton';

interface CPFDisplayProps {
  cpf: string;
}

export function CPFDisplay({ cpf }: CPFDisplayProps) {
  return (
    <div className="flex items-center justify-center space-x-2">
      <span className="text-2xl font-mono">{cpf}</span>
      <CopyButton text={cpf} />
    </div>
  );
}