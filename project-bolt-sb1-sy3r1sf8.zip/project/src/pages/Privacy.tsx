export function Privacy() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      <div className="prose lg:prose-lg">
        <p>
          At CNP Tools, we take your privacy seriously. This policy outlines how we handle your data:
        </p>
        <ul>
          <li>All CNP validation and generation is performed locally in your browser</li>
          <li>We do not store or transmit any personal information</li>
          <li>No cookies are used for tracking purposes</li>
          <li>No data is shared with third parties</li>
        </ul>
        <h2>Data Processing</h2>
        <p>
          When you use our CNP validator or generator:
        </p>
        <ul>
          <li>All calculations are performed in your browser</li>
          <li>No data is sent to our servers</li>
          <li>No personal information is stored</li>
        </ul>
      </div>
    </div>
  );
}