import { useEffect, useState } from 'react';
import { getCNPRecords, getAdminSettings } from '../../services/adminService';
import { CNPRecord, AdminSettings } from '../../types/admin';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { UserList } from '../../components/admin/UserList';
import { CNPRecordList } from '../../components/admin/CNPRecordList';
import { SettingsPanel } from '../../components/admin/SettingsPanel';

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<'users' | 'records' | 'settings'>('users');
  const [records, setRecords] = useState<CNPRecord[]>([]);
  const [settings, setSettings] = useState<AdminSettings[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [recordsData, settingsData] = await Promise.all([
        getCNPRecords(),
        getAdminSettings()
      ]);
      setRecords(recordsData);
      setSettings(settingsData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="text-red-600">{error}</div>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>
      
      <div className="mb-6 border-b">
        <nav className="flex gap-4">
          {(['users', 'records', 'settings'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-2 px-4 ${
                activeTab === tab
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        {activeTab === 'users' && <UserList />}
        {activeTab === 'records' && <CNPRecordList records={records} />}
        {activeTab === 'settings' && (
          <SettingsPanel settings={settings} onUpdate={loadData} />
        )}
      </div>
    </div>
  );
}