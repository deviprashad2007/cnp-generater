import { Hero } from '../components/home/Hero';
import { Features } from '../components/home/Features';
import { InfoSection } from '../components/home/InfoSection';
import { CNPGenerator } from '../components/CNPGenerator';

export function Home() {
  return (
    <div>
      <Hero />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <CNPGenerator />
      </div>
      <Features />
      <InfoSection />
    </div>
  );
}