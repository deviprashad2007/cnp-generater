export interface BlogPost {
  id: number;
  title: string;
  content: string;
  excerpt: string;
  image_url?: string;
  author_name: string;
  author_avatar?: string;
  created_at: string;
  updated_at: string;
}