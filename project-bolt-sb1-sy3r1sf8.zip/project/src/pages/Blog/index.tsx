import { useEffect, useState } from 'react';
import { BlogPost } from '../../types/blog';
import { BlogList } from '../../components/blog/BlogList';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { getBlogPosts } from '../../services/blogService';

export function Blog() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchPosts() {
      try {
        const data = await getBlogPosts();
        setPosts(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch blog posts');
      } finally {
        setLoading(false);
      }
    }

    fetchPosts();
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Blog</h1>
      
      {error && (
        <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      {loading ? <LoadingSpinner /> : <BlogList posts={posts} />}
    </div>
  );
}