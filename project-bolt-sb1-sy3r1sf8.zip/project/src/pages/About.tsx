export function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">About CNP Tools</h1>
      <div className="prose lg:prose-lg">
        <p>
          CNP Tools is a specialized application designed to work with Romanian Personal Numerical Codes (CNP).
          Our tools are built with accuracy and security in mind, following the official specifications for CNP validation and generation.
        </p>
        <h2>What is a CNP?</h2>
        <p>
          The Personal Numerical Code (CNP) is a unique identifier assigned to each Romanian citizen and resident.
          It consists of 13 digits that encode information about:
        </p>
        <ul>
          <li>Gender and century of birth</li>
          <li>Date of birth</li>
          <li>County of birth</li>
          <li>Unique sequence number</li>
          <li>Control digit</li>
        </ul>
      </div>
    </div>
  );
}