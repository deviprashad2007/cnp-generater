export type Gender = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export interface CNPComponents {
  gender: Gender;
  year: number;
  month: number;
  day: number;
  county: string;
  sequence: number;
  control: number;
}