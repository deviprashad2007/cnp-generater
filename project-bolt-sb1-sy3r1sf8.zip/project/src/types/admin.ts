export interface CNPRecord {
  id: string;
  cnp: string;
  gender: string;
  birth_date: string;
  county_code: string;
  created_at: string;
  created_by: string;
}

export interface AdminSettings {
  id: string;
  setting_key: string;
  setting_value: any;
  updated_at: string;
  updated_by: string;
}

export interface AdminUser {
  id: string;
  email: string;
  role: string;
  created_at: string;
}