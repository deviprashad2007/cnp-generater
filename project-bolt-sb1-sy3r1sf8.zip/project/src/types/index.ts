export interface County {
  name: string;
  code: string;
}

export type Gender = 'male' | 'female';