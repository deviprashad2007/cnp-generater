export interface Database {
  public: {
    Tables: {
      blog_posts: {
        Row: {
          id: number;
          title: string;
          content: string;
          excerpt: string;
          image_url: string | null;
          author_name: string;
          author_avatar: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['blog_posts']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['blog_posts']['Insert']>;
      };
    };
  };
}