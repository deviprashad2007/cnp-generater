export interface BlogPost {
  id: number;
  title: string;
  content: string;
  excerpt: string;
  image_url?: string | null;
  author_name: string;
  author_avatar?: string | null;
  created_at: string;
  updated_at: string;
}

export interface BlogCardProps {
  post: BlogPost;
}