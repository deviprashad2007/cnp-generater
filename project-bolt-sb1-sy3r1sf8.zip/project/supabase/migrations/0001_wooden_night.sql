/*
  # Admin Backend Schema

  1. New Tables
    - `cnp_records`
      - Stores generated CNP records with metadata
      - Includes user info and generation timestamp
    - `admin_settings`
      - Stores admin configuration
      - Controls generation rules and restrictions

  2. Security
    - Enable RLS on all tables
    - Add policies for admin access
*/

-- Create CNP records table
CREATE TABLE IF NOT EXISTS cnp_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cnp text NOT NULL,
  gender text NOT NULL,
  birth_date date NOT NULL,
  county_code text NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

-- Create admin settings table
CREATE TABLE IF NOT EXISTS admin_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value jsonb NOT NULL,
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE cnp_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;

-- Policies for CNP records
CREATE POLICY "Admins can read all CNP records"
  ON cnp_records
  FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Users can read their own CNP records"
  ON cnp_records
  FOR SELECT
  TO authenticated
  USING (auth.uid() = created_by);

-- Policies for admin settings
CREATE POLICY "Only admins can manage settings"
  ON admin_settings
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');